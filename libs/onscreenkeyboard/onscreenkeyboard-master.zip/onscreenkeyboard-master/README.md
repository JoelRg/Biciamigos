jQuery On-screen keyboard
================

This is a simple on-screen keyboard powered by JavaScript/jQuery.

Demo: http://www.jquery4u.com/demos/onscreenkeyboard/

Article: http://www.sitepoint.com/jquery-on-screen-keyboard/

[![jQuery On-screen keyboard](http://dab1nmslvvntp.cloudfront.net/wp-content/uploads/jquery4u/2013/05/29-05-2013-4-27-26-PM.jpg "jQuery On-screen keyboard")](http://www.jquery4u.com/demos/onscreenkeyboard/)

jQuery Mobile Screen Keyboard
================
This version has been modified for jQuery Mobile and has other features here: https://github.com/grburgos/mobilescreenkeyboard

Credits to: [@grburgos](https://github.com/grburgos/)

The MIT License (MIT)
================

Copyright © 2015 Sam Deering, http://samdeering.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
